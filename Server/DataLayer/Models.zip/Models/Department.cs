#nullable disable

namespace DataLayer.Models 
{
    public class Departmnet
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public ICollection<User> Teachers { get; set; } = [];
    }
}
