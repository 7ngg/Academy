namespace DataLayer.Models
{
    public enum Roles
    {
        ADMIN,
        TEACHER,
        STUDENT
    }
}
