#nullable disable

namespace DataLayer.Models
{
    public class Group
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string FacultyId { get; set; }
        public Faculty Faculty { get; set; }

        public ICollection<User> Students { get; set; } = [];
    }
}
